<!DOCTYPE html>
<html>
<head>
	<title>Navigation Panel</title>
</head>
<body>
<nav class="navbar navbar-default">
	<div class="container">
	</div>
</nav>
		
</body>
</html>