<?php
  session_start();
  if(isset($_POST['submit'])){
    $_SESSION['sentence'] = $_POST['sentence'];
    echo $_SESSION['sentence'];
    if(isset($_SESSION['id'])){
      header('Location: Resultpage.php');
    }
  }
?>