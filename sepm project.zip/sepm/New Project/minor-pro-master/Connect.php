<?php
    include('config.php');
   if(isset($_POST['Login']))
     {  
       
      $name=$_POST['fname'];
      
      $email=$_POST['email'];
      
      $sel ="select * from minor where email='$name' and email='$email'";
      $query=mysqli_query($con,$sel);
      if($fetch=mysqli_fetch_assoc($query))
      {
        $fname=$fetch['fname'];
        $id=$fetch['id'];
        $_SESSION['login_user']=$name;
        $_SESSION['id']=$id;
        if(isset($_SESSION['sentence'])){
          header('Location: Resultpage.php');
        }
        else{
          header('Location: Frontend.php');
        }
        
      }
      else
      {
         echo "Login failed.";
      }
    }
   ?>